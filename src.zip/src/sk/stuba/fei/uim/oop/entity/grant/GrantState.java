package sk.stuba.fei.uim.oop.entity.grant;

public enum GrantState {
    STARTED,
    EVALUATING,
    CLOSED
}
